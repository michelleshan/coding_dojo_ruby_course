class IdeasController < ApplicationController
  before_action :require_login
  def index
    @user = current_user
    # @ideas = Idea.all
    @ideas = Idea.all
    # @ideas = Idea.joins(:likes).select('ideas.*, COUNT(likes.id) as likes_count').group('ideas.id').order('likes_count DESC')
    # ^ this code excludes any idea with 0 likes and I couldn't find a way to include them without using left joins which is not a feature of Rails 4 :(
  end

  def create
    @idea = Idea.create(idea_params)
    if @idea.save
      redirect_to dashboard_path
    else
      flash[:errors] = @idea.errors.full_messages
      redirect_to dashboard_path
    end
  end

  def show
    @idea = Idea.find(params[:id])
  end

  def destroy
    idea = Idea.find(params[:id])
    idea.destroy
    redirect_to dashboard_path
  end

  private
  def idea_params
    params.require(:idea).permit(:content, :user_id)
  end

end
