class LikesController < ApplicationController
  def create
    if params[:user_id] == session[:user_id].to_s
      Like.create(idea_id: params[:idea_id], user_id: params[:user_id])
      redirect_to dashboard_path
    else
      flash[:errors] = ["You cannot like ideas for other people"]
      redirect_to dashboard_path
    end
  end
end
