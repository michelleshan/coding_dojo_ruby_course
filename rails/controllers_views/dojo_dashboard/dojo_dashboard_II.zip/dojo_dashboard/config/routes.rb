Rails.application.routes.draw do
  # get 'dojos' => 'dojos#index'
  # get 'dojos/new' => 'dojos#new'
  # post 'dojos/create' => 'dojos#create'
  resources :dojos
end
