Rails.application.routes.draw do
  get 'dojos' => 'dojos#index'
  
end
