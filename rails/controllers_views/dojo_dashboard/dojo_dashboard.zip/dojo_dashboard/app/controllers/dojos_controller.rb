class DojosController < ApplicationController
  def index
    @count ||= 0
    @dojos = Dojo.all
    @dojos.each { |dojo| @count += 1}
  end
end
