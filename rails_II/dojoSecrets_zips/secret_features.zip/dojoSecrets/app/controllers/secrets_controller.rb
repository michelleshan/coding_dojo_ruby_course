class SecretsController < ApplicationController
  def index
    @secrets = Secret.all
  end

  def create
    @secret = Secret.create(secret_params)
    if @secret.save
      redirect_to user_path(current_user)
    else
      flash[:errors] = @secret.errors.full_messages
      redirect_to user_path(current_user)
    end
  end

  def destroy
    @secret = Secret.find(params[:id])
    @secret.destroy
    redirect_to user_path(current_user)
  end

  private
  def secret_params
    params.require(:secret).permit(:content, :user_id)
  end
end
