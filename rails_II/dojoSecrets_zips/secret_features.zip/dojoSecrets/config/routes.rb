Rails.application.routes.draw do
  get 'secrets/:id/delete' => 'secrets#destroy', as: 'delete_secret'
  get 'reset' => 'sessions#destroy'
  resources :users
  resources :sessions
  resources :secrets
end
